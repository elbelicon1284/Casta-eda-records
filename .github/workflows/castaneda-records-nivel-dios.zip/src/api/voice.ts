import axios from "axios";

export const clonarVoz = async (file:any)=>{
  const form = new FormData();
  form.append("file",file);

  const res = await axios.post(
    "https://api.elevenlabs.io/v1/speech-to-speech",
    form,
    {
      headers:{ "xi-api-key":"TU_API_KEY" }
    }
  );

  return res.data;
};
