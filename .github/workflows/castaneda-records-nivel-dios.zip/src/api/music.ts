import axios from "axios";

export const generarMusica = async (prompt:string) => {
  const res = await axios.post("https://api.replicate.com/v1/predictions",{
    version:"riffusion",
    input:{prompt}
  },{
    headers:{
      Authorization:"Token TU_API_KEY"
    }
  });

  return res.data;
};
