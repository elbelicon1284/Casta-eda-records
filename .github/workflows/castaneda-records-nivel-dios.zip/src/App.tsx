import {useState} from 'react'
import { motion } from 'framer-motion'

export default function App(){

const [audio,setAudio]=useState('')
const [file,setFile]=useState(null)

const upload=(e:any)=>{
 const f=e.target.files[0]
 setFile(f)
 setAudio(URL.createObjectURL(f))
}

return(
<div style={{padding:20}}>

<h1>🔥 Castañeda Records IA</h1>

<motion.button whileTap={{scale:0.9}}>
Generar Hit
</motion.button>

<input type="file" accept="audio/*" onChange={upload}/>

{audio && <audio controls src={audio}/>}

</div>
)
}
